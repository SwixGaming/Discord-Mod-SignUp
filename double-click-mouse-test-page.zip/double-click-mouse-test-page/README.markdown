# double click mouse test page

A Pen created on CodePen.io. Original URL: [https://codepen.io/blink172/pen/vERyxK](https://codepen.io/blink172/pen/vERyxK).

javascript double click mouse test page
